methods::setGeneric(name = "addTableNoWarning<-", def = function(x, ..., value) standardGeneric("addTableNoWarning<-"))
methods::setGeneric(name = "addTableWarning<-", def = function(x, value, ...) standardGeneric("addTableWarning<-"))
